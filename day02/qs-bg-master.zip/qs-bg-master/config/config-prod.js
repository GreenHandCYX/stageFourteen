/**
 * the configuration for production
 */
module.exports = {
  PORT: 8080,
  IP: '127.0.0.1',
  http: 'http://qs.huoqishi.net',
  https: 'https://qs.huoqishi.net'
}
