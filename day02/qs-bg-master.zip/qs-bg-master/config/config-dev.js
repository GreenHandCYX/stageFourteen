/**
 * the configuration for development
 */
module.exports = {
  PORT: 8080,
  IP: '127.0.0.1'
}
